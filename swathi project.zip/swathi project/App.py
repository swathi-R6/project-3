import streamlit as st
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sn
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn import metrics
import time
import hashlib



# Function to hash passwords
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

# Load user data from Excel
def load_users():
    try:
        return pd.read_excel("users.xlsx")
    except FileNotFoundError:
        return pd.DataFrame(columns=["Username", "Name", "Password"])

# Save user data to Excel
def save_user(username, name, password):
    users_df = load_users()
    if username in users_df["Username"].values:
        return False
    new_user = pd.DataFrame({"Username": [username], "Name": [name], "Password": [hash_password(password)]})
    users_df = pd.concat([users_df, new_user], ignore_index=True)
    users_df.to_excel("users.xlsx", index=False)
    return True

# Authenticate user
def authenticate(username, password, users_df):
    hashed_password = hash_password(password)
    user_record = users_df[(users_df["Username"] == username) & (users_df["Password"] == hashed_password)]
    return not user_record.empty

# Streamlit UI for Login
st.set_page_config(page_title="Login & Signup", page_icon="🔐", layout="centered")
st.markdown("""
    <style>
    body { background-color: #E0F7FA; }
    .stTextInput, .stButton > button { border-radius: 12px; padding: 10px; }
    .stButton > button { background-color: #0277BD; color: white; font-weight: bold; }
    .stButton > button:hover { background-color: #01579B; }
    </style>
    """, unsafe_allow_html=True)

st.markdown("<h2 style='text-align: center; color: #01579B;'>Welcome to Your Personal Fitness Tracker</h2>", unsafe_allow_html=True)

if "authenticated" not in st.session_state:
    st.session_state["authenticated"] = False

if not st.session_state["authenticated"]:
    option = st.radio("Select an option:", ["Login", "Signup"], horizontal=True)
    if option == "Login":
        username = st.text_input("👤 Username", key="login_username")
        password = st.text_input("🔑 Password", type="password", key="login_password")
        login_button = st.button("Login")
        if login_button:
            users_df = load_users()
            if authenticate(username, password, users_df):
                st.success("✨ Login Successful! ✨")
                st.session_state["authenticated"] = True
                st.rerun()
            else:
                st.error("❌ Invalid Username or Password")
    elif option == "Signup":
        new_username = st.text_input("👤 Choose a Username", key="signup_username")
        name = st.text_input("📛 Full Name", key="signup_name")
        new_password = st.text_input("🔑 Create Password", type="password", key="signup_password")
        confirm_password = st.text_input("🔑 Confirm Password", type="password", key="signup_confirm_password")
        signup_button = st.button("Sign Up")
        if signup_button:
            if new_password != confirm_password:
                st.error("❌ Passwords do not match!")
            elif save_user(new_username, name, new_password):
                st.success("🎉 Signup Successful! You can now log in.")
            else:
                st.error("❌ Username already exists. Choose another.")
    st.stop()


import warnings
warnings.filterwarnings('ignore')

st.header("🤰 Pregnancy Exercise Tracker")
exercise_categories = {
    "Warm-Up & Mobility": ["Shoulder Rolls", "Neck Stretches", "Arm Circles", "Side-to-Side Toe Taps", "Hip Circles"],
    "Low-Impact Cardio": ["Marching in Place", "Side Step Touches", "Seated Knee Lifts", "Step-Ups", "Slow Jumping Jacks"],
    "Strength Training": ["Bodyweight Squats", "Wall Push-Ups", "Seated Shoulder Press", "Bicep Curls", "Resistance Band Rows"],
    "Core & Pelvic Floor": ["Pelvic Tilts", "Cat-Cow", "Bird-Dog", "Seated Knee Lifts", "Side-Lying Leg Lifts"],
    "Lower Body Strength": ["Glute Bridges", "Leg Extensions", "Calf Raises", "Inner Thigh Squeezes", "Clamshells"],
    "Upper Body Strength": ["Shoulder Shrugs", "Triceps Dips", "Lat Pulls", "Arm Raises", "Reverse Flys"],
    "Stretching & Flexibility": ["Butterfly Stretch", "Side Stretches", "Forward Fold", "Quadriceps Stretch", "Shoulder Stretch"],
}

category = st.selectbox("Select an Exercise Category:", list(exercise_categories.keys()))
st.write("### Exercises:")
st.write("\n".join([f"- {exercise}" for exercise in exercise_categories[category]]))

# Dance categories and calorie burn per hour (for 70kg person)
dance_data = {
    "Classical & Cultural Dances": {
        "Ballet": 500, "Kathak": 500, "Bharatanatyam": 600, "Odissi": 550, "Kuchipudi": 600, 
        "Mohiniyattam": 450, "Flamenco": 450, "Belly Dancing": 375, "Hula": 325, "Irish Step Dance": 600
    },
    "Street & Hip-Hop Styles": {
        "Hip-Hop Dance": 650, "Breakdancing": 750, "Popping & Locking": 500, "Krumping": 800, "House Dance": 625
    },
    "Social & Ballroom Dances": {
        "Salsa": 500, "Tango": 325, "Waltz": 300, "Foxtrot": 325, "Quickstep": 500,
        "Rumba": 325, "Cha-Cha-Cha": 500, "Jive": 575, "Samba": 625, "Swing Dance": 625
    },
    "Latin & Afro-Caribbean Dances": {
        "Zumba": 650, "Merengue": 500, "Bachata": 400, "Cumbia": 425, "Reggaeton": 625
    },
    "Folk & Traditional Dances": {
        "Garba": 625, "Bhangra": 750, "Kalbelia": 500, "Polka": 425, "Square Dance": 375, "Line Dancing": 325
    },
    "Fitness & Contemporary Dances": {
        "Aerobic Dance": 750, "Step Dance Aerobics": 850, "Jazz Dance": 500, "Modern Dance": 425, 
        "Freestyle Dance": 525, "K-Pop Dance Workouts": 650
    },
    "Exotic & High-Energy Dances": {
        "Bollywood Dance": 650, "Capoeira": 750, "Twerking": 500, "Can-Can": 625, "Shuffle Dance": 575
    },
    "Club & Party Dances": {
        "Electronic Dance": 750, "Disco": 500, "Techno/Club Dancing": 650
    }
}

# Streamlit UI
st.title("Dance Calories Burned Calculator 🕺💃")

# Select Dance Category
category = st.selectbox("Select Dance Category:", list(dance_data.keys()))

# Select Specific Dance
if category:
    dance = st.selectbox("Select Dance Style:", list(dance_data[category].keys()))
    calories_per_hour = dance_data[category][dance]  # Get calories burned per hour

    # Select Duration
    duration = st.slider("Select Dance Duration (minutes):", 15, 240, 30, 15)

    # Calculate Calories Burned
    calories_burned = (calories_per_hour / 60) * duration

    # Display Results
    st.subheader(f"🔥 Calories Burned: *{calories_burned:.2f} kcal*")
    st.info(f"Dancing {dance} for {duration} minutes burns approximately {calories_burned:.2f} kcal.")

st.sidebar.header("User Input Parameters: ")

def user_input_features():
    age = st.sidebar.slider("Age: ", 10, 100, 30)
    bmi = st.sidebar.slider("BMI: ", 15, 40, 20)
    duration = st.sidebar.slider("Duration (min): ", 0, 35, 15)
    heart_rate = st.sidebar.slider("Heart Rate: ", 60, 130, 80)
    body_temp = st.sidebar.slider("Body Temperature (C): ", 36, 42, 38)
    gender_button = st.sidebar.radio("Gender: ", ("Male", "Female"))

    gender = 1 if gender_button == "Male" else 0

    # Use column names to match the training data
    data_model = {
        "Age": age,
        "BMI": bmi,
        "Duration": duration,
        "Heart_Rate": heart_rate,
        "Body_Temp": body_temp,
        "Gender_male": gender  # Gender is encoded as 1 for male, 0 for female
    }

    features = pd.DataFrame(data_model, index=[0])
    return features

df = user_input_features()

st.write("---")
st.header("Your Parameters: ")
latest_iteration = st.empty()
bar = st.progress(0)
for i in range(100):
    bar.progress(i + 1)
    time.sleep(0.01)
st.write(df)

# Load and preprocess data
calories = pd.read_csv("calories.csv")
exercise = pd.read_csv("exercise.csv")

exercise_df = exercise.merge(calories, on="User_ID")
exercise_df.drop(columns="User_ID", inplace=True)

exercise_train_data, exercise_test_data = train_test_split(exercise_df, test_size=0.2, random_state=1)

# Add BMI column to both training and test sets
for data in [exercise_train_data, exercise_test_data]:
    data["BMI"] = data["Weight"] / ((data["Height"] / 100) ** 2)
    data["BMI"] = round(data["BMI"], 2)

# Prepare the training and testing sets
exercise_train_data = exercise_train_data[["Gender", "Age", "BMI", "Duration", "Heart_Rate", "Body_Temp", "Calories"]]
exercise_test_data = exercise_test_data[["Gender", "Age", "BMI", "Duration", "Heart_Rate", "Body_Temp", "Calories"]]
exercise_train_data = pd.get_dummies(exercise_train_data, drop_first=True)
exercise_test_data = pd.get_dummies(exercise_test_data, drop_first=True)

# Separate features and labels
X_train = exercise_train_data.drop("Calories", axis=1)
y_train = exercise_train_data["Calories"]

X_test = exercise_test_data.drop("Calories", axis=1)
y_test = exercise_test_data["Calories"]

# Train the model
random_reg = RandomForestRegressor(n_estimators=1000, max_features=3, max_depth=6)
random_reg.fit(X_train, y_train)

# Align prediction data columns with training data
df = df.reindex(columns=X_train.columns, fill_value=0)

# Make prediction
prediction = random_reg.predict(df)

st.write("---")
st.header("Prediction: ")
latest_iteration = st.empty()
bar = st.progress(0)
for i in range(100):
    bar.progress(i + 1)
    time.sleep(0.01)

st.write(f"{round(prediction[0], 2)} *kilocalories*")

st.write("---")
st.header("Similar Results: ")
latest_iteration = st.empty()
bar = st.progress(0)
for i in range(100):
    bar.progress(i + 1)
    time.sleep(0.01)

# Find similar results based on predicted calories
calorie_range = [prediction[0] - 10, prediction[0] + 10]
similar_data = exercise_df[(exercise_df["Calories"] >= calorie_range[0]) & (exercise_df["Calories"] <= calorie_range[1])]
st.write(similar_data.sample(5))

st.write("---")
st.header("General Information: ")

# Boolean logic for age, duration, etc., compared to the user's input
boolean_age = (exercise_df["Age"] < df["Age"].values[0]).tolist()
boolean_duration = (exercise_df["Duration"] < df["Duration"].values[0]).tolist()
boolean_body_temp = (exercise_df["Body_Temp"] < df["Body_Temp"].values[0]).tolist()
boolean_heart_rate = (exercise_df["Heart_Rate"] < df["Heart_Rate"].values[0]).tolist()

st.write("You are older than", round(sum(boolean_age) / len(boolean_age), 2) * 100, "% of other people.")
st.write("Your exercise duration is higher than", round(sum(boolean_duration) / len(boolean_duration), 2) * 100, "% of other people.")
st.write("You have a higher heart rate than", round(sum(boolean_heart_rate) / len(boolean_heart_rate), 2) * 100, "% of other people during exercise.")
st.write("You have a higher body temperature than", round(sum(boolean_body_temp) / len(boolean_body_temp), 2) * 100, "% of other people during exercise.")


# Load or initialize user data
if "user_data" not in st.session_state:
    st.session_state["user_data"] = {"steps": 0, "streak": 0, "last_active": None}

# Title
st.title("Personal Fitness Tracker 🏃‍♂🔥")

# Step Counter & Daily Goal
st.header("Step Counter & Daily Goal Setting")
step_goal = st.number_input("Set Your Daily Step Goal", min_value=1000, max_value=50000, value=10000, step=500)
steps_today = st.number_input("Enter Your Steps Today", min_value=0, value=st.session_state["user_data"]["steps"], step=100)
st.session_state["user_data"]["steps"] = steps_today

# Step Goal Progress
progress = min(steps_today / step_goal, 1.0)
st.progress(progress)
st.write(f"You've completed *{progress * 100:.2f}%* of your daily step goal!")

# Initialize session state for tracking outdoor activity
if "activity_data" not in st.session_state:
    st.session_state.activity_data = []
if "tracking" not in st.session_state:
    st.session_state.tracking = False

# Function to start tracking
def start_tracking():
    st.session_state.tracking = True
    st.session_state.activity_data = []  # Reset tracking data

# Function to stop tracking
def stop_tracking():
    st.session_state.tracking = False

# Function to track location & calculate distance
def track_location():
    location = st.experimental_get_query_params()  # Simulating GPS data (For real-world use, integrate GPS API)
    
    if "lat" in location and "lon" in location:
        lat, lon = float(location["lat"][0]), float(location["lon"][0])
        current_time = time.strftime("%H:%M:%S")

        if st.session_state.activity_data:
            prev_lat, prev_lon = st.session_state.activity_data[-1]["lat"], st.session_state.activity_data[-1]["lon"]
            distance = geodesic((prev_lat, prev_lon), (lat, lon)).meters
        else:
            distance = 0  # First point has no previous distance

        st.session_state.activity_data.append({"lat": lat, "lon": lon, "time": current_time, "distance": distance})

# Streamlit UI
st.title("🏃 Outdoor Activity Tracker")
st.write("Track your distance, speed & route in real-time!")

activity_type = st.selectbox("Select Activity Type:", ["Walking", "Running", "Cycling", "Hiking"])

if st.button("Start Tracking"):
    start_tracking()
    st.success("✅ Tracking Started! Move around to track your route.")

if st.session_state.tracking:
    track_location()
    st.write("📍 Tracking Your Activity...")

if st.button("Stop Tracking"):
    stop_tracking()
    st.success("🛑 Tracking Stopped.")

# Display Tracked Data
if st.session_state.activity_data:
    df = pd.DataFrame(st.session_state.activity_data)
    total_distance = df["distance"].sum() / 1000  # Convert meters to km
    st.metric("Total Distance Covered", f"{total_distance:.2f} km")

    # Map Route
    m = folium.Map(location=[df["lat"].iloc[0], df["lon"].iloc[0]], zoom_start=15)
    for _, row in df.iterrows():
        folium.Marker([row["lat"], row["lon"]], popup=row["time"]).add_to(m)
    folium_static(m)

    # Show Data Table
    st.dataframe(df)

    # Breathing Exercises
breathing_exercises = {
    "Box Breathing (4-4-4-4)": {
        "inhale": 4, "hold": 4, "exhale": 4, "hold_after": 4
    },
    "4-7-8 Breathing": {
        "inhale": 4, "hold": 7, "exhale": 8, "hold_after": 0
    },
    "Deep Relaxation Breathing": {
        "inhale": 5, "hold": 5, "exhale": 7, "hold_after": 0
    }
}

# UI
st.title("🌬 Breathing & Mindfulness Coach")
st.write("Relax, reduce stress, and improve focus with guided breathing exercises.")

exercise = st.selectbox("Choose a Breathing Exercise:", list(breathing_exercises.keys()))
duration = st.slider("Select Duration (minutes):", 1, 10, 3)

if st.button("Start Breathing Session"):
    st.success("🧘‍♂ Follow the guide below & sync your breathing.")

    inhale_time = breathing_exercises[exercise]["inhale"]
    hold_time = breathing_exercises[exercise]["hold"]
    exhale_time = breathing_exercises[exercise]["exhale"]
    hold_after_time = breathing_exercises[exercise]["hold_after"]

    total_cycles = (duration * 60) // (inhale_time + hold_time + exhale_time + hold_after_time)

    for i in range(int(total_cycles)):
        st.write("⬆ *Inhale* for", inhale_time, "seconds")
        time.sleep(inhale_time)

        if hold_time:
            st.write("⏳ *Hold* for", hold_time, "seconds")
            time.sleep(hold_time)

        st.write("⬇ *Exhale* for", exhale_time, "seconds")
        time.sleep(exhale_time)

        if hold_after_time:
            st.write("⏳ *Hold After Exhale* for", hold_after_time, "seconds")
            time.sleep(hold_after_time)

    st.success("✅ Breathing session completed! Feel the calm. 😌")

# Mindfulness Timer
st.header("🕰 Mindfulness Timer")
mindfulness_time = st.slider("Select Mindfulness Time (minutes):", 1, 20, 5)
if st.button("Start Mindfulness Timer"):
    st.success("🧘‍♀ Close your eyes and focus on your breath. Timer is running.")
    time.sleep(mindfulness_time * 60)
    st.success("✅ Mindfulness session completed!")